document.addEventListener("DOMContentLoaded", function () {
  // Add any interactive functionality here if needed
});
